import java.util.ArrayList;
import java.util.Collection;


public class Directory {
	private ArrayList<Employee> dir;
	private Collection<String> collection;
	
	//default constructor initializes directory
	public Directory(){
		dir = new ArrayList<Employee>();
	}
	
	//constructor for importing already filled directory
	public Directory(ArrayList<Employee> a){
		dir = a;
	}
	
	
	//add employee to directory
	// needs to alphabetize employees upon adding them
	public void add(Employee employee){
		dir.add(employee);
		
	}
	//adds whole list to off employees
	public void add(ArrayList<Employee> list){
		for(int i = 0;i < list.size();i++){
			dir.add(list.get(i));
			
		}

	}
	public void sort(ArrayList<Employee> list){}
	
	
	//takes out alphabetized directory
	public void print(){
		if(dir.size() == 0){
			System.out.println("<Directory is Empty>");
		}
		
		for(int i = 0; i < dir.size(); i++ ){
			System.out.println(dir.get(i).toString());
		}
		
	}
	
	//clears the directory
	public void clear(){
		dir = new ArrayList<Employee>();
		//dir = null;
	}
	
	//ToDo
	public void fromJSON(){
	
		if(collection.size() == 0){
			dir = new ArrayList<Employee>();
		}
		
		for(int i = 0; i < dir.size();i++){
			collection.add(dir.get(i).toString());
		}
	}

}
