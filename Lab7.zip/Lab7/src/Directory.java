import java.util.ArrayList;



public class Directory {
	private ArrayList<Employee> dir;
	private ArrayList<String> collection;
	
	//default constructor initializes directory
	public Directory(){
		dir = new ArrayList<Employee>();
	}
	
	//constructor for importing already filled directory
	public Directory(ArrayList<Employee> a){
		dir = a;
	}
	
	
	//add employee to directory
	// sort upon new additions to directory
	public void add(Employee employee){
		dir.add(employee);
		sort(dir);
		
	}
	//adds whole list to of employees
	public void add(ArrayList<Employee> list){
		for(int i = 0;i < list.size();i++){
			dir.add(list.get(i));
			
		}
		sort(dir);

	}
	//selection sort implementation for our directory
	public void sort(ArrayList<Employee> list){
		String one;
		String two;
		Employee temp;
		
		for(int i = 0; i < dir.size(); i++){
			one = dir.get(i).getLast() + " " + dir.get(i).getFirst();
			for(int j = i +1;j < dir.size(); j++){
				two = dir.get(j).getLast() + " " + dir.get(j).getFirst();
				if(one.compareTo(two) > 0){		//if dir[i] should be alphabetically after dir[j] then swap the two
					temp = dir.get(i);
					dir.set(i, dir.get(j));
					dir.set(j, temp);
				}
			}
		}
		
	}
	
	//print out alphabetized directory
	public void print(){
		if(dir.size() == 0){
			System.out.println("<Directory is Empty>");
		}
		
		for(int i = 0; i < dir.size(); i++ ){
			System.out.println(dir.get(i).toString());
		}
		
	}
	
	//clears the directory
	public void clear(){
		dir = new ArrayList<Employee>();
	}
	
	//reconstruct directory from passed in JSON formatted list of employees
	//could dump all of reconstructed employees into a list and then add the whole list to directory in one go instead of individual additions
	public void fromJSON(ArrayList<String> arr){
		collection = arr;
		String[] tokens;
		String[] tokensTwo;
		String _firstName;
		String _lastName;
		String _phone;
		String _department;
	
		if(collection.size() == 0){
			dir = new ArrayList<Employee>();
		}
		
		for(int i = 0; i < collection.size();i++){
			
			tokens = collection.get(i).split("_"); //tokens[0] is gonna be an empty string
			tokensTwo = tokens[1].split(" : ");		//split again to grab each value from each variable
			_firstName = tokensTwo[1].trim();	//remove any whitespace
			
			tokensTwo = tokens[2].split(" : ");
			_lastName = tokensTwo[1].trim();
			
			tokensTwo = tokens[3].split(" : ");
			_phone = tokensTwo[1].trim();
			
			tokensTwo = tokens[4].split(" : ");
			_department = tokensTwo[1].trim();
			
			add(new Employee(_lastName, _firstName, _phone, _department)); //add reconstituted employees one by one into main directory
			
		}
	}

}
