import java.util.ArrayList;
import java.util.Collection;

import java.util.Scanner;



public class DirectoryEditor {
	
	public static void main(String[] args){
		
		DirectoryProxy proxy = new DirectoryProxy();
		Scanner sc = new Scanner (System.in);
		String cmd = "";
		String employee = "";
		boolean flag;
		
		do {
			System.out.print("Enter Command: ");
			cmd = sc.nextLine();
			flag = false;
			do {
				switch(cmd.toUpperCase()) {
					case "ADD": 	System.out.println("Enter Employee(s) [FirstName LastName Department Phone] :");
									while(!employee.equalsIgnoreCase("END")){
										employee = sc.nextLine();
										if(!employee.equalsIgnoreCase("END")){
											proxy.add(employee); // static?
										}
									
									}
									employee = null;
									flag = true;
									break;
					case "CLR":		proxy.clear(); // static?
									flag = true;
									break;
					case "PRINT":	proxy.print(); // static?
									flag = true;
									break;
					default: 		System.out.println("Invalid Command");
									flag = true;
									break;
				}
			} while (!flag);
		
		} while (!cmd.equalsIgnoreCase("quit"));
		
		sc.close();
	}
}


