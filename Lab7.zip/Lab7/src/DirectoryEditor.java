import java.util.Scanner;



public class DirectoryEditor {
	
	public static void main(String[] args){
		
		DirectoryProxy proxy = new DirectoryProxy();
		Directory dir = new Directory();
		Scanner sc = new Scanner (System.in);
		String cmd = "";
		String employee = "";
		boolean flag;
		
		do {
			System.out.print("Enter Command: ");
			cmd = sc.nextLine();
			flag = false;
			do {
				switch(cmd.toUpperCase()) {
					case "ADD": 	System.out.println("Enter Employee(s) [FirstName LastName Department Phone] :");
									while(!employee.equalsIgnoreCase("END")){
										employee = sc.nextLine();
										if(!employee.equalsIgnoreCase("END")){
											proxy.add(employee); // add employee to proxy directory
										}
									
									}
									employee = "";
									dir.fromJSON(proxy.toJSON());  //dismantle proxy directory into string and then pass into main directory server to reassemble
									proxy.clear();					//clear proxy directory after its served its purpose
									flag = true;
									break;
					case "CLR":		dir.clear(); // clear main server directory
									flag = true;
									break;
					case "PRINT":	dir.print(); // print content of main directory 
									flag = true;
									break;
					default: 		System.out.println("Invalid Command");
									flag = true;
									break;
				}
			} while (!flag);
		
		} while (!cmd.equalsIgnoreCase("quit"));
		
		sc.close();
	}
}


