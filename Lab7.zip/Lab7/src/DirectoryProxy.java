import java.util.ArrayList;
import java.util.Collection;


public class DirectoryProxy {
	private ArrayList<Employee> dir;
	private Collection<String> collection;
	
	//default constructor initializes directory
	public DirectoryProxy(){
		dir = new ArrayList<Employee>();
	}
	
	//constructor for importing already filled directory
	public DirectoryProxy(ArrayList<Employee> a){
		dir = a;
	}
	
	
	//add employee to directory
	// needs to alphabetize employees upon adding them
	public void add(Employee employee){
		dir.add(employee);
		
	}
	
	//adds whole list to off employees
	public void add(ArrayList<Employee> list){
		for(int i = 0;i < list.size();i++){
			dir.add(list.get(i));
			
			}

	}
	public void add(String s) {
		String[] strArr = s.split(" ");
		dir.add(new Employee(strArr[1], strArr[0], strArr[3], strArr[2]));
		sort(dir); // comparator research
	}
	
	public void sort(ArrayList<Employee> list){
		String one;
		String two;
		Employee temp;
		
		for(int i = 0; i < dir.size(); i++){
			one = dir.get(i).getLast() + " " + dir.get(i).getFirst();
			for(int j = i +1;j < dir.size(); j++){
				two = dir.get(j).getLast() + " " + dir.get(j).getFirst();
				if(one.compareTo(two) > 0){		//if dir[i] should be alphabetically after dir[j] then swap the two
					temp = dir.get(i);
					dir.set(i, dir.get(j));
					dir.set(j, temp);
				}
			}
		}
		
	}
	
	//takes out alphabetized directory
	public void print(){
		if(dir.size() == 0){
			System.out.println("<Directory is Empty>");
		}
		
		for(int i = 0; i < dir.size(); i++ ){
			System.out.println(dir.get(i).toString());
		}
		
	}
	
	//clears the directory
	public void clear(){
		dir = new ArrayList<Employee>();
		//dir = null;
	}
	
	public void toJSON(){
		if(dir.size() == 0){
			collection.add(null);
		}
		
		//add all elements in proxy directory to collection to get ready to pass into main Directory
		for(int i = 0; i < dir.size();i++){
			collection.add(dir.get(i).toString());
		}
		
		
		
		
	}
		
	

}
