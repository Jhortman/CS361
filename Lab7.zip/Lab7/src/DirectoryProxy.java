import java.util.ArrayList;



public class DirectoryProxy {
	private ArrayList<Employee> dir;
	private ArrayList<String> collection;
	
	//default constructor initializes directory
	public DirectoryProxy(){
		dir = new ArrayList<Employee>();
	}
	
	//constructor for importing already filled directory
	public DirectoryProxy(ArrayList<Employee> a){
		dir = a;
	}
	
	
	//add employee to directory
	public void add(Employee employee){
		dir.add(employee);
		
	}
	
	//adds whole list to off employees
	public void add(ArrayList<Employee> list){
		for(int i = 0;i < list.size();i++){
			dir.add(list.get(i));
			
			}
		//sort(dir);
		

	}
	public void add(String s) {
		String[] strArr = s.split(" ");
		dir.add(new Employee(strArr[1], strArr[0], strArr[3], strArr[2]));
		//sort(dir); // sort everytime we add a new entry 
	}
	
	//implementing selection sort for our directory
	/*public void sort(ArrayList<Employee> list){
		String one;
		String two;
		Employee temp;
		
		for(int i = 0; i < dir.size(); i++){
			one = dir.get(i).getLast() + " " + dir.get(i).getFirst();
			for(int j = i +1;j < dir.size(); j++){
				two = dir.get(j).getLast() + " " + dir.get(j).getFirst();
				if(one.compareTo(two) > 0){		//if dir[i] should be alphabetically after dir[j] then swap the two
					temp = dir.get(i);
					dir.set(i, dir.get(j));
					dir.set(j, temp);
				}
			}
		}
		
	}
	*/
	
	//prints out alphabetized directory
	public void print(){
		if(dir.size() == 0){
			System.out.println("<Directory is Empty>");
		}
		
		for(int i = 0; i < dir.size(); i++ ){
			System.out.println(dir.get(i).toString());
		}
		
	}
	
	//clears the proxy directory
	public void clear(){
		dir = new ArrayList<Employee>();
	}
	
	public ArrayList<String> toJSON(){
		String _firstName;
		String _lastName;
		String _phone;
		String _department;
		
		String _json;
		collection = new ArrayList<String>();
		if(dir.size() == 0){
			collection.add(null);
		}
		
		//break down all elements in proxy directory to a collection of strings in JSON format to get ready to pass into main Directory
		//return the collection to be passed into main server
		for(int i = 0; i < dir.size();i++){
			_firstName = "_firstName : " + dir.get(i).getFirst();
			_lastName = " _lastName : " + dir.get(i).getLast();
			_phone = " _phone : " + dir.get(i).getPhone();
			_department = " _department : " + dir.get(i).getDepart();
			
			_json = _firstName + _lastName + _phone + _department;
			collection.add(_json);
		}
		
		return collection;
	}
				
}
