
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        TestSimulator.class,
        TestSprint1.class, 
        TestSprint2.class, 
        TestSprint3.class, 
        TestSprint4.class, 
        Testing.class 

})
public class TestSuite {

}