
import org.junit.Test;
import static org.junit.Assert.*;

public class Testing {
	
	
	//private Chronotimer ct = new Chronotimer();
	
	
	@Test
	public void testGrp() {
		
		
		//tests done to mimick sprint3.txt
		//ct.COMMANDS("power");
		
		
		//check time
		//ct.COMMANDS("TIME 12:01:30.0");
		//assertEquals("12:01:30.0", Time.getTimeAsString());
		
		//check if anyruns are active
		
		//assertEquals(null, ct._curRun );
		
		
		
		
		
	
	}
}