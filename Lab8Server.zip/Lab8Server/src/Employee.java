
public class Employee implements Comparable<Object> {
	private String _lastName;
	private String _firstName;
	private String _phone;
	private String _department;
	private String _gender;
	private String _title;
	
	public Employee(String last, String first, String num, String depart, String gender, String title){
		_lastName = last;
		_firstName = first;
		_phone = num;
		_department = depart;
		_gender = gender;
		_title = title;
	}
	
	public void setLast(String last){
		_lastName = last;
	}
	public void setFirst(String first){
		_firstName = first;
	}
	public void setPhone(String phone){
		_phone = phone;
	}
	public void setDepart(String depart){
		_department = depart;
	}
	
	public String getLast(){ return _lastName;}
	
	public String getFirst(){ return _firstName;}
	
	public String getPhone(){ return _phone; }
	
	public String getDepart(){ return _department; }
	
	@Override
	public String toString(){
		
		return _title + " " + _lastName + ", " + _firstName + " (Sex: " + _gender + ") " +  _phone + " " + _department;
	}
	
	//need for comparing employee objects on server in a collection list
	@Override
	public int compareTo(Object o) {
		if (o instanceof Employee) {
			Employee other = (Employee) o;
			int ret = _lastName.compareTo(other._lastName);
			if(ret == 0) {
				ret = _firstName.compareTo(other._firstName);
			}
			return ret;
		}
		return 0;
	}

}
