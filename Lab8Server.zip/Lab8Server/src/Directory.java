import java.util.ArrayList;
import java.util.Collection;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import java.io.FileWriter;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;



public class Directory {
	private ArrayList<Employee> dir;
	//private ArrayList<String> collection;
	
	//default constructor initializes directory
	public Directory(){
		dir = new ArrayList<Employee>();
	}
	
	public ArrayList<Employee> getDir() {
		return dir;
	}
	
	//method for adding JSON string into directory
	//sort directory after adding
	public void add(String JSON) {
			ArrayList<Employee> tempList = new Gson().fromJson(JSON, new TypeToken<Collection<Employee>>() {}.getType());
			dir.addAll(tempList);
			
			sort(dir);
		}
	
	//build up our html string to get ready to write it to file and out to the browser at /displayresults
	public String toHTML() {
		
		String html = "";
		
		html += "<!DOCTYPE html>\n<html>\n<head>\n<link rel=\"stylesheet\" type=\"text/css\" href=\"displayresults/style.css\">\n</head>\n" + 
				"<body>\n<h2> Company Directory</h2>\n<table>\n<caption></caption>\n<tr>\n<th>Title</th>\n" +
				"<th>First Name</th>\n<th>Last Name</th>\n<th>Department</th>\n<th>Phone</th>\n<th>Gender</th>\n</tr>\n";
			
		//filling our html table with employees
		for (Employee e: dir) {
			html += "<tr>\n"
				 + "<td>" + e.getTitle() + "</td>\n" 
				 + "<td>" + e.getFirst() + "</td>\n"
				 + "<td>" + e.getLast() + "</td>\n"
				 + "<td>" + e.getDepart() + "</td>\n"
				 + "<td>" + e.getPhone() + "</td>\n"
				 + "<td>" + e.getGender() + "</td>\n"
				 + "</tr>\n";
		}
		
		html += "</table>\n</body>\n</html>";
		
		
		try{    
	           FileWriter file = new FileWriter("HTML.html");		//create html file
	           file.write(html);									//write out string to html file
	           file.close(); 
	          }catch(IOException e){
	        	  System.out.println(e);
	          }  
		
		return html;
		
	}
	
	//compiling our style.css file into one big string to hand over to the server to stash it at /displayresults/style.css 
	//in order for our html file to find and access it
	public String getCSS() {
		String css = "";
		
		try {
			Scanner sc = new Scanner(new File("style.css"));
			
			while (sc.hasNext()){
				css += sc.nextLine();		
			}
			
			sc.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			}
		return css;
	}
	
	//selection sort implementation for our directory
	public void sort(ArrayList<Employee> list){
		String one;
		String two;
		Employee temp;
		
		for(int i = 0; i < dir.size(); i++){
			one = dir.get(i).getLast() + " " + dir.get(i).getFirst();
			for(int j = i +1;j < dir.size(); j++){
				two = dir.get(j).getLast() + " " + dir.get(j).getFirst();
				if(one.compareTo(two) > 0){		//if dir[i] should be alphabetically after dir[j] then swap the two
					temp = dir.get(i);
					dir.set(i, dir.get(j));
					dir.set(j, temp);
				}
			}
		}
		
	}
	
	//print out alphabetized directory
	public void print(){
		if(dir.size() == 0){
			System.out.println("<Directory is Empty>");
		}
		
		
		for(int i = 0; i < dir.size(); i++ ){
			System.out.println(dir.get(i).toString());
		}
		
	}
	
	//clears the directory
	public void clear(){
		dir = new ArrayList<Employee>();
	}
	

}
