import java.util.ArrayList;
import java.util.Collection;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;



public class Directory {
	private ArrayList<Employee> dir;
	//private ArrayList<String> collection;
	
	//default constructor initializes directory
	public Directory(){
		dir = new ArrayList<Employee>();
	}
	
	public ArrayList<Employee> getDir() {
		return dir;
	}
	
	//method for adding JSON string into directory
	//sort directory after adding
		public void add(String JSON) {
			ArrayList<Employee> tempList = new Gson().fromJson(JSON, new TypeToken<Collection<Employee>>() {}.getType());
			dir.addAll(tempList);
			
			sort(dir);
		}
	
	
	//selection sort implementation for our directory
	public void sort(ArrayList<Employee> list){
		String one;
		String two;
		Employee temp;
		
		for(int i = 0; i < dir.size(); i++){
			one = dir.get(i).getLast() + " " + dir.get(i).getFirst();
			for(int j = i +1;j < dir.size(); j++){
				two = dir.get(j).getLast() + " " + dir.get(j).getFirst();
				if(one.compareTo(two) > 0){		//if dir[i] should be alphabetically after dir[j] then swap the two
					temp = dir.get(i);
					dir.set(i, dir.get(j));
					dir.set(j, temp);
				}
			}
		}
		
	}
	
	//print out alphabetized directory
	public void print(){
		if(dir.size() == 0){
			System.out.println("<Directory is Empty>");
		}
		
		
		for(int i = 0; i < dir.size(); i++ ){
			System.out.println(dir.get(i).toString());
		}
		
	}
	
	//clears the directory
	public void clear(){
		dir = new ArrayList<Employee>();
	}
	

}
