import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Chronotimer {
	private Channel[] _channels;
	private String _event;
	private LinkedList<Integer> _racers;
	private Scanner stdIn;
	private Time time;

	public Chronotimer() {
		_channels = new Channel[8];
		for(int i = 0; i < 8; i++) _channels[i] = new Channel(i);
		_event = null;
		_racers = new LinkedList<Integer>();
		time = new Time();
		stdIn = new Scanner(System.in);
	}
	public void start() {
		String s = null;
		String[] tokens;
		do {
			System.out.println("Enter command: ");
			s = stdIn.nextLine();
			tokens = s.split(" ");
			
			switch (tokens[0].toUpperCase()) {
			case "POWER"	: POWER();break;
			case "EXIT"		: EXIT();break;
			case "RESET"	: RESET();break;
			case "TIME"		: TIME(tokens[1]);break;
			case "DNF"		: DNF();break;
			case "CANCEL"	: CANCEL();break;
			case "TOG"		: TOG(Integer.parseInt(tokens[1]) - 1);break;
			case "TRIG"		: TRIG(Integer.parseInt(tokens[1]) - 1);break;
			case "START"	: START(); break;
			case "FINISH"	: FINISH();  break;
			case "SHOWTIME"	: showTime(); break;
			
			default: System.out.println("bad input"); break;
			
			}
		} while (true);
	}
	private void POWER() { // maybe use boolean true/false to toggle this 
		throw new IllegalStateException(); 
	}
	private void EXIT() {
		System.exit(0);
	}
	private void RESET() {
		new Chronotimer();
	}
	private void TIME(String s) {
		time.setTime(s);
	}
	private void DNF() {
		
	}
	private void CANCEL() {
		
	}
	private void TOG(int i) {
		_channels[i].toggleState();
		if(_channels[i].getState()) {
			System.out.println(_channels[i].getNum() + " is active.");
		}
		else {
			System.out.println(_channels[i].getNum() + " is Shutting Down.");
		}
	}
	private void TRIG(int i) {
		
		if(_channels[i].getState() && ((_channels[i].getNum() % 2) == 1)){// trigger start only if channel is on and parity is odd 
			time.start();
			System.out.println("Start is: " + time.getStart());
		}
		if(_channels[i].getState() && ((_channels[i].getNum() % 2) == 0)){// trigger finish only if channel is on and parity is even 
			time.finish();
			System.out.println("Finish is: " + time.getFinish());
		}
		//else do nothing
	}
	public void START() {   // same as triggering start on channel 1
		
		if(_channels[0].getState()) {
			time.start();
			System.out.println("Start is: " + time.getStart());
		}
		
		
		
		/*System.out.println(time.getTime());
		time.start("5:24:15.8");
		System.out.println(time.getStart());
		System.exit(0);
		*/
	}
	private void FINISH() {  // same as triggering finish on channel 2
		
		if(_channels[0].getState()) {
			time.finish();
			System.out.println("Finish is: " + time.getFinish());
		}
	}
	
	private void showTime() {
		System.out.println("race time is: " + time.totalTime());;
	}
//	private void CONN(String s, int i) {
//		try {
//			if (s.toUpperCase().equals("EYE")  || 
//				s.toUpperCase().equals("GATE") ||
//				s.toUpperCase().equals("PAD")    ) _channels[i].setSensor(s);
//			else System.out.println("Unknown sensor type '" + s + "'");
//		} catch (IndexOutOfBoundsException e) {
//			System.out.println("Invalid channel number");
//		}
//	}
//	private void DISC(int i) {
//		try {
//			_channels[i].disconnect();
//		} catch (IndexOutOfBoundsException e) {
//			System.out.println("Invalid channel number");
//		}
//	}
//	private void EVENT(String s) {
//		if (s.toUpperCase().equals("IND")	 || 
//			s.toUpperCase().equals("PARIND") ||
//			s.toUpperCase().equals("GRP")    ||
//			s.toUpperCase().equals("PARGRP")   ) _event = s;
//		else System.out.println("Unknown event type '" + s + "'");
//	}
}
