import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Chronotimer {
	private Channel[] _channels;
	private String _event;
	private LinkedList<Integer> _racers;
	private Scanner stdIn;
	private Time time;

	public Chronotimer() {
		_channels = new Channel[8];
		for(int i = 0; i < 8; i++) _channels[i] = new Channel(i);
		_event = null;
		_racers = new LinkedList<Integer>();
		time = new Time();
		stdIn = new Scanner(System.in);
	}
	public void staart() {
		String s = null;
		do {
			System.out.println("Enter command: ");
			s = stdIn.next();
			switch (s.toUpperCase()) {
			case "POWER"	: POWER();
			case "EXIT"		: EXIT();
			case "RESET"	: RESET();
			case "TIME"		: TIME();
			case "DNF"		: DNF();
			case "CANCEL"	: CANCEL();
			case "TOG"		: TOG(1);
			case "TRIG"		: TRIG();
			case "START"	: START();
			case "FINISH"	: FINISH();
			
			}
		} while (true);
	}
	private void POWER() {
		throw new IllegalStateException();
	}
	private void EXIT() {
		throw new RuntimeException();
	}
	private void RESET() {
		
	}
	private void TIME() {
		time.getTime();
	}
	private void DNF() {
		
	}
	private void CANCEL() {
		
	}
	private void TOG(int i) {
		_channels[i].toggleState();
	}
	private void TRIG() {
		
	}
	public void START() {
		System.out.println(time.getTime());
		time.start("5:24:15.8");
		System.out.println(time.getStart());
		System.exit(0);
	}
	private void FINISH() {
		
	}
//	private void CONN(String s, int i) {
//		try {
//			if (s.toUpperCase().equals("EYE")  || 
//				s.toUpperCase().equals("GATE") ||
//				s.toUpperCase().equals("PAD")    ) _channels[i].setSensor(s);
//			else System.out.println("Unknown sensor type '" + s + "'");
//		} catch (IndexOutOfBoundsException e) {
//			System.out.println("Invalid channel number");
//		}
//	}
//	private void DISC(int i) {
//		try {
//			_channels[i].disconnect();
//		} catch (IndexOutOfBoundsException e) {
//			System.out.println("Invalid channel number");
//		}
//	}
//	private void EVENT(String s) {
//		if (s.toUpperCase().equals("IND")	 || 
//			s.toUpperCase().equals("PARIND") ||
//			s.toUpperCase().equals("GRP")    ||
//			s.toUpperCase().equals("PARGRP")   ) _event = s;
//		else System.out.println("Unknown event type '" + s + "'");
//	}
}
