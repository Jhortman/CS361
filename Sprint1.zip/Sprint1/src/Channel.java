
public class Channel {
	private boolean _state;
	private int _number;
	private String _sensor;
	public Channel(int i) {
		_state = false;
		_number = i;
		_sensor = null;
	}
	public void toggleState() {
		_state = !_state;
	}
	public void setSensor(String s) {
		_sensor = s;
	}
	public void disconnect() {
		_sensor = null;
	}
}
