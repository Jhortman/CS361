import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;



public class DirectoryProxy {
	private ArrayList<Employee> dir;
	//private ArrayList<String> collection;
	
	//default constructor initializes directory
	public DirectoryProxy(){
		dir = new ArrayList<Employee>();
	}
	
	//constructor for importing already filled directory
	public DirectoryProxy(ArrayList<Employee> a){
		dir = a;
	}
	public void sendPost(String JSON) {
		try {
			System.out.println("in the client");

			// Client will connect to this location
			URL site = new URL("http://localhost:8000/sendresults");
			HttpURLConnection conn = (HttpURLConnection) site.openConnection();

			// now create a POST request
			conn.setRequestMethod("POST");
			conn.setDoOutput(true);
			conn.setDoInput(true);
			DataOutputStream out = new DataOutputStream(conn.getOutputStream());

			// build a string that contains JSON from console
			String content = "";
			content = JSON;

			// write out string to output buffer for message
			out.writeBytes(content);
			out.flush();
			out.close();

			System.out.println("Done sent to server");

			InputStreamReader inputStr = new InputStreamReader(conn.getInputStream());

			// string to hold the result of reading in the response
			StringBuilder sb = new StringBuilder();

			// read the characters from the request byte by byte and build up
			// the Response
			int nextChar;
			while ((nextChar = inputStr.read()) > -1) {
				sb = sb.append((char) nextChar);
			}
			System.out.println("Return String: " + sb);

		} catch (Exception e) {
			e.printStackTrace();
		}
	
	}
	
	
	
	//add employee to directory
	public void add(Employee employee){
		dir.add(employee);
		
	}
	
	//adds whole list to off employees
	public void add(ArrayList<Employee> list){
		for(int i = 0;i < list.size();i++){
			dir.add(list.get(i));
			
			}
		//sort(dir);
		

	}
	
	public ArrayList<Employee> getDir(){
		return dir;
	}
	/*
	public void add(String s) {
		String[] strArr = s.split(" ");
		dir.add(new Employee(strArr[1], strArr[0], strArr[3], strArr[2]));
		//sort(dir); // sort everytime we add a new entry 
	}
	*/
	
	//implementing selection sort for our directory
	/*public void sort(ArrayList<Employee> list){
		String one;
		String two;
		Employee temp;
		
		for(int i = 0; i < dir.size(); i++){
			one = dir.get(i).getLast() + " " + dir.get(i).getFirst();
			for(int j = i +1;j < dir.size(); j++){
				two = dir.get(j).getLast() + " " + dir.get(j).getFirst();
				if(one.compareTo(two) > 0){		//if dir[i] should be alphabetically after dir[j] then swap the two
					temp = dir.get(i);
					dir.set(i, dir.get(j));
					dir.set(j, temp);
				}
			}
		}
		
	}
	*/
	
	//prints out alphabetized directory
	public void print(){
		if(dir.size() == 0){
			System.out.println("<Directory is Empty>");
		}
		
		for(int i = 0; i < dir.size(); i++ ){
			System.out.println(dir.get(i).toString());
		}
		
	}
	
	//clears the proxy directory
	public void clear(){
		dir = new ArrayList<Employee>();
	}
	/*
	public ArrayList<String> toJSON(){
		String _firstName;
		String _lastName;
		String _phone;
		String _department;
		
		String _json;
		collection = new ArrayList<String>();
		if(dir.size() == 0){
			collection.add(null);
		}
		
		//break down all elements in proxy directory to a collection of strings in JSON format to get ready to pass into main Directory
		//return the collection to be passed into main server
		for(int i = 0; i < dir.size();i++){
			_firstName = "_firstName : " + dir.get(i).getFirst();
			_lastName = " _lastName : " + dir.get(i).getLast();
			_phone = " _phone : " + dir.get(i).getPhone();
			_department = " _department : " + dir.get(i).getDepart();
			
			_json = _firstName + _lastName + _phone + _department;
			collection.add(_json);
		}
		
		return collection;
	}
	*/
			
				
}
